# V23.5C.2A.1 — 2026-07-29

- Restored visible official podcast media actions across episode pages, series pages, the podcast directory, and the Somewhere in the Skies gateway.
- Loaded the V23.5A universal media compatibility helper before the entity renderer.
- Added simultaneous support for `officialMedia`, `official_media`, and preserved legacy fields with canonical duplicate suppression.
- Added preferred-media rendering and a permanent failure test for eligible media with no public action.
- Preserved all official media URLs and all knowledge-graph data.

## V23.5B — Existing Podcast Official Media Migration

Migrated 257 podcast episodes and four series entities to the universal official-media collection. Preserved all legacy fields, corrected destination labels, activated preferred-link resolution, suppressed 467 duplicate legacy URL occurrences, and verified zero unauthorized non-media changes.

# V23.2 — Somewhere in the Skies 2017 Podcast Integration

- Added 40 unique Somewhere in the Skies releases published in 2017: 36 numbered episodes and four non-numbered feed releases.
- Classified every release through the internal V23 engine and committed approved classification records.
- Populated the existing Somewhere in the Skies gateway with 2017 year, topic, search, sorting, and combined-filter data.
- Added Research Episode, Standard Episode, and Catalog Record metadata without exposing internal review data publicly.
- Reused the canonical podcast-series entity and limited graph links to source-supported relationships.
- Added a reproducible archive reconciliation and validation report.
- Preserved architecture, schemas, rendering templates, navigation, routing, styling, and existing podcast content.

# V23.1 — Podcast Classification Engine Release Visibility Patch

- Updated the homepage Latest Additions section with the V23.0 Podcast Classification Engine release.
- Updated the homepage Development Updates section with the V23.1 documentation-only patch.
- Verified the V23.0 release summary in `data/release-summary.json`.
- Verified the Podcast Classification Engine documentation and referenced configuration/schema files.
- Added no code, entity, episode, relationship, knowledge-graph, rendering, navigation, routing, UI, or styling changes.

# V23.0 — Podcast Classification Engine

- Added an internal, human-reviewed podcast classification layer to Research Accelerator draft generation.
- Determines Content Class, Episode Type, primary and secondary topics, processing depth, and canonical entity extraction targets.
- Requires explicit reviewer approval before import and does not publish or create canonical entities automatically.
- Keeps classification metadata internal and leaves existing public pages unchanged.

## V22.1.1 — Somewhere in the Skies Archive Gateway
- Added a native GreyAlien gateway for Somewhere in the Skies.
- Combined year and topic browsing with keyword search, sorting, compact episode rows, and pagination.
- Added an ingestion-ready archive index covering 2017–2026 and nine research-topic collections.
- Reused the existing canonical podcast-series entity and official links.
- Updated the podcast directory, homepage Latest Additions, sitemap, and validation documentation.
- No episode entities were created and no knowledge-graph schema or relationship data were changed.

# V22.1 — MERGED Podcast Integration (Complete Series)

- Added MERGED Episodes 2–19 as production-quality podcast entities.
- Completed the 19-episode MERGED collection with canonical reuse, source-grounded claims, direct episode media references, and cross-series graph integration.
- Added only missing guest entities; no architecture or engine changes.

# V21.3 — Need to Know Podcast Integration Batch 4 (2026-07-24)

- Added Need to Know Episodes #17–21 as complete podcast episode entities.
- Added 20 source-grounded principal claims and five podcast-publication timeline events.
- Reused canonical Nimitz encounter, Ryan Graves, Jeremy Corbell, Garry Nolan, Luis Elizondo, AARO, UAP Task Force, FY2022 NDAA, and established topic entities.
- Used direct official video links for all five releases, including the official 7NEWS Spotlight video for Episode #20.
- Retained the official Need to Know YouTube collection as the secondary reference source.
- Preserved all platform architecture and existing WEAPONIZED relationships.

# V21.1 — Need to Know Podcast Integration Batch 2 (2026-07-22)

- Added Need to Know Episodes #2–6 as complete podcast episode entities.
- Added 20 source-grounded principal claims and five podcast-publication timeline events.
- Reused canonical Ross Coulthart, Bryce Zabel, Harry Reid, Roswell Incident, White House, United States Congress, and established topic entities.
- Added narrowly required canonical records for the FY2022 NDAA, World War II foo fighter reports, and 1946 Scandinavian ghost rocket reports.
- Replaced the generic archive reference on Need to Know Episodes #1–6 with each episode’s direct official YouTube URL.
- Retained the official Need to Know YouTube collection as the secondary reference source.
- Preserved all platform architecture and existing WEAPONIZED relationships.

# V21 — Need to Know Podcast Integration Pilot

- Added Need to Know Episode #1, “2021 Top Ten,” as a complete podcast episode entity.
- Reused canonical Need to Know, Ross Coulthart, Bryce Zabel, and topic entities.
- Added four source-grounded principal claims and one publication timeline event.
- Rebuilt cross-series related content, reciprocal graph discovery, unique counts, entity pages, podcast indexes, homepage, and sitemap.
- Made no architecture, schema, rendering, template, navigation, routing, UI, styling, or platform changes.

# V20.6 — Knowledge Graph Enrichment, Batch C

- Enriched Jeremy Corbell and George Knapp with six narrowly selected, source-supported relationships.
- Added direct Jellyfish UAP reporting, Skinwalker Ranch investigation, and November 2024 House hearing evidence-contribution connections.
- Preserved all existing valid graph content and reciprocal episode discovery.
- Added no entities and made no architecture, schema, rendering, template, navigation, routing, UI, or styling changes.
- Rebuilt and validated reciprocal discovery, unique connection counts, and duplicate-card suppression.

# V20.3 — Knowledge Graph Enrichment Pilot: Whitley Strieber

- Confirmed `transformation-2026` as the canonical Transformation 2026 document entity.
- Added the source-supported author relationship between Whitley Strieber and Transformation 2026.
- Added Whitley Strieber’s missing direct appearance relationship to WEAPONIZED Episode #120.
- Preserved the existing Episode #120-to-document relationship.
- Documented unsupported enrichment opportunities rather than adding speculative relationships.
- Rebuilt and validated reciprocal rendering and relationship counts.

# V20 — WEAPONIZED Podcast Optimization — Phase 1

- Corrected WEAPONIZED episode connection ordering to use true numeric episode sequence rather than filename or lexical order.
- Removed the Related Timeline section from podcast episode pages.
- No other architecture, rendering, template, schema, navigation, UI, styling, routing, or content changes.

# V19.9 — WEAPONIZED Episodes #113–#120

- Added Episodes #113, #114, and #116–#120 as content-only production records.
- Preserved the existing Episode #115 record without duplication or replacement.
- Added 35 source-grounded principal claims and seven publication timeline events.
- Updated Latest Additions, Development Updates, relationship counts, podcast indexes, related content, entity pages, and sitemap outputs.
- No architecture, rendering, template, schema, navigation, UI, styling, or routing changes.

# V19.8 — WEAPONIZED Episodes #32–#41

- Added ten WEAPONIZED episode records (#32–#41).
- Added 40 source-grounded principal claims and ten publication timeline events.
- Updated Latest Additions, Development Updates, podcast indexes, graph outputs, related content, entity pages, and sitemap.
- Content-only production ingestion; no platform changes.

# V19.7 — WEAPONIZED Episodes 22–31 Backfill

- Added the nine previously missing records: Episodes #22–#27 and #29–#31.
- Preserved the existing Episode #21 and Episode #28 entities and relationships.
- Added 36 source-grounded principal claims and nine podcast-publication timeline events.
- Added or reused canonical people, organizations, hearings, cases, and topics.
- Updated Latest Additions, Development Updates, release metadata, graph outputs, podcast indexes, related content, entity pages, and sitemap.
- No architecture, rendering, template, schema, navigation, UI, styling, or routing changes.

# V19.6 — WEAPONIZED Episodes 11–20

- Added WEAPONIZED Episodes #11–#20 as content-only production records.
- Added 40 source-grounded principal claims and 10 podcast-publication timeline events.
- Added or reused canonical people, organizations, and case entities.
- Updated Latest Additions, Development Updates, release metadata, graph outputs, podcast indexes, related content, entity pages, and sitemap.
- No architecture, rendering, template, schema, navigation, UI, styling, or routing changes.

## V19.1.1 — WEAPONIZED Episodes #73–#82 Production Batch

- Added production episode records and source-grounded claims for Episodes #73–#82.
- Reused canonical entities and introduced only genuinely new people, organizations, and cases.
- Rebuilt graph, podcast indexes, related content, entity pages, homepage, sitemap, and validation reports.
- No architectural changes.

# V19.0 — WEAPONIZED Episodes #63–#72 Production Batch

- Added production episode records for WEAPONIZED Episodes #63 through #72.
- Added source-grounded principal claims for all ten episodes.
- Reused canonical entities whenever available and added new person, organization, topic, and case records only where the batch introduced genuinely new knowledge.
- Added official WEAPONIZED episode-page and audio-feed references.
- Rebuilt and validated the graph, podcast indexes, related content, generated entity pages, homepage, and sitemap.
- Introduced no platform architecture, rendering-engine, template, navigation, schema, relationship-engine, UI/UX, or automation-framework changes.

# V18.5 — WEAPONIZED Episodes #58–#62 Production Batch

- Added production episode records for WEAPONIZED Episodes #58, #59, #60, #61, and #62.
- Added sourced principal-claim records for Episodes #58, #59, #61, and #62.
- Added Lester Nare, Matt Laslo, and Rory Kremer as connected person entities.
- Added UAP Caucus, Ask a Pol, Transmedium UAP, and the 2024 UK Military Airspace Incursions as supporting graph records.
- Preserved the correct official `/episodes-3/` URLs for Episodes #61 and #62.
- Kept Episode #60 limited to verified series-level metadata because the official page provides no episode-specific synopsis, guests, cases, or claims.
- Rebuilt and validated the graph, podcast indexes, related content, entity pages, homepage, and sitemap.

# V18.4 — Research Accelerator

- Added a review-first podcast research accelerator using official episode pages, saved HTML, and optional transcripts.
- Added automatic metadata extraction, existing-entity matching, draft relationship generation, confidence scoring, and human-review checklists.
- Preserved editorial safety: the accelerator does not modify the live graph or auto-publish claims.
- Added a five-episode WEAPONIZED manifest template for Episodes #58–#62.
- Added automated fixture validation to the standard build pipeline.
- Updated homepage Latest Additions.

# V18.2.1 — WEAPONIZED Visual Identity Test (Corrected)

- Added the actual live WEAPONIZED series banner and responsive styles.
- Used a factual, non-portrait editorial identity to avoid synthetic likenesses.
- Added structured visual identity metadata and accessibility text.
- Added visual identity validation to the automation pipeline.
- Updated homepage Latest Additions.

# V18.1 — First Five-Episode Production Batch

- Ingested WEAPONIZED Episodes #43–#47 in one transactional batch.
- Added seven supporting person, organization, topic, and case records.
- Rebuilt the graph, podcast indexes, related content, generated pages, homepage, and sitemap.
- Established the baseline timing benchmark for comparison with the Research Accelerator.

## V18.0 — First Automated Knowledge Ingestion

- Ingested WEAPONIZED Episode #42 through the transactional import system.
- Added Joe Murgia as a connected person entity and correctly distinguished him as guest.
- Connected the episode to Garry Nolan and David Grusch as discussed subjects.
- Connected the episode to the Sol Foundation, UAP Disclosure Act, and inaugural Sol Foundation symposium.
- Updated the importer to include V17.4 rendering-rule and V17.5 timeline-normalization automation steps.
- Updated homepage Latest Additions through structured release metadata.

# V17.5 — Timeline Normalization Engine

- Added canonical timeline-event alias generation.
- Deduplicated timeline cards by canonical historical event.
- Preserved distinct media and timeline entities in the graph.
- Changed the hero statistic label from Connections to Unique connections.
- Added timeline normalization validation to the one-command automation pipeline.

# GreyAlien Changelog

## V17.4 — Automation Engine Refinement
- Grouped relationship cards by target entity category rather than relationship type.
- Unified interviews and podcast episodes under one Related Media section.
- Preserved relationship-specific badges on every card.
- Added `data/schema/rendering-groups.json` as the centralized rendering configuration.
- Added automated rendering-rule validation to the one-command build.
- Updated Latest Additions for the V17.4 deployment.

# V17.2 — Import System

- Added transactional single-record and folder-based batch imports.
- Added preflight metadata, URL, date, relationship, and podcast-semantic validation.
- Added dry-run mode, conflict protection, explicit replacement mode, and machine-readable reports.
- Added stable generated HTML entry points for every knowledge-base entity.
- Updated sitemap generation to use stable crawlable entity URLs.
- Added staged full-build verification so failed imports cannot partially modify the live package.
- Updated homepage Latest Additions.

# V17.1 — Podcast Engine

- Added canonical podcast series and episode schemas.
- Added ingestion package and one-command episode workflow.
- Added generated podcast-series, episode, and manifest indexes.
- Added podcast semantic validation and deterministic sitemap building.
- Migrated six researched WEAPONIZED records to `podcast_episode`.
- Updated podcast cards with generated episode and connected-entity totals.
- Updated homepage Latest Additions.

# GreyAlien Version 16.0 — Science & Technology Gateway Foundation

- Replaced the legacy Science & Technology placeholder with a complete visual gateway.
- Added seven collection cards with a distinct icon and accent system.
- Added seven responsive collection landing pages with purposeful Coming Soon content.
- Established future routing for disciplines, sensors, programs, methods, explanations, research publications, and emerging technologies.
- Added breadcrumb navigation, SEO metadata, CollectionPage structured data, and sitemap entries.
- Preserved all existing podcast, entity, hearing, homepage, and knowledge-graph content.

# GreyAlien Version 15.19 — Wave 2D Timeline Expansion

- Added focused UAP-related timelines for Michael Herrera, Eric Hecker, and Jonathan Weygandt.
- Reused the existing Indonesia, South Pole, and Peru case entities as dated canonical milestones.
- Added one shared June 12, 2023 National Press Club disclosure event for Herrera and Hecker.
- Added Eric Hecker's 2010–2011 South Pole assignment as necessary context for his later public claims.
- Corrected Jonathan Weygandt's archived Disclosure Project interview chronology to 2001 and added his September 6, 2023 Podcast UFO interview.
- Applied the Canonical Event Watch List and the editorial directive that each milestone must directly affect the UAP narrative.

# GreyAlien Version 15.18 — Wave 2C Timeline Expansion

- Added focused UAP timelines for Hal Puthoff, Eric Davis, and Matthew Brown.
- Reused the existing NIDS, AAWSAP, To The Stars Academy, and WEAPONIZED entities wherever authoritative records already existed.
- Added one shared NIDS milestone, one shared AAWSAP technical-research milestone, and a carefully attributed Wilson–Davis Notes document entity.
- Completed Matthew Brown's chronology by dating and reusing WEAPONIZED Episodes #74, #75, and #76.
- Applied the editorial rule that each milestone must directly affect the UAP narrative.
- Applied the Canonical Event Watch List to prevent parallel records for the same occurrence.

# GreyAlien Version 15.17 — Wave 2B Timeline Expansion

- Added focused UAP timelines for Garry Nolan, Sean M. Kirkpatrick, and Jacques Vallée.
- Reused the existing April 19, 2023 AARO hearing, NASA public meeting, and Sol Foundation symposium records.
- Added canonical publication entities for three foundational Jacques Vallée works.
- Applied the editorial rule that each milestone must directly affect the UAP narrative.

# GreyAlien V15.16.1

- Added Wave 2A Related Timeline coverage for Karl Nell, Luis Elizondo, and Avi Loeb.
- Applied the relevance rule that a milestone must directly affect the UAP research, disclosure, policy, or scientific narrative.
- Added Karl Nell milestones for UAP Task Force support, the inaugural Sol Foundation symposium, and his May 2024 SALT disclosure presentation.
- Added Luis Elizondo milestones for his 2017 transition to public UAP advocacy, his Galileo Project affiliate appointment, the publication of *Imminent*, and reused the existing November 2024 House hearing.
- Added Avi Loeb milestones for founding the Galileo Project, the IM1 expedition, the shared Galileo affiliate announcement, and the inaugural Sol Foundation symposium.
- Reused existing organization and hearing entities instead of creating parallel Timeline records.
- Preserved Timeline filtering, chronological sorting, canonical-entity reuse, and the V15.16 Entity Explorer UX.

# GreyAlien V15.16

- Added dynamic Entity Explorer category navigation with live counts from the entity index.
- Made the category navigator sticky so visitors can move between sections without returning to the top.
- Added active-section highlighting, smooth scrolling, and a floating back-to-top control.
- Refined Entity Explorer hero copy, section counts, section-header consistency, and empty-state handling.
- Improved large-directory rendering and responsive navigation behavior without changing any entity data or relationships.
- Deferred Entity Search to a future release.

# GreyAlien V15.15.1

- Removed the redundant Timeline Event for the December 4, 2018 release of *Bob Lazar: Area 51 & Flying Saucers*.
- Removed the redundant Timeline Event for WEAPONIZED Episode #115 published April 14, 2026.
- Preserved the existing documentary and podcast episode entities as the authoritative dated Timeline records.
- Standardized Episode #115 on the canonical title: **WEAPONIZED Episode #115 — A New Chapter in the Bob Lazar Saga**.
- Removed “Entity System 1.0” from the Entity Explorer hero.
- Preserved all remaining Timeline relationships, chronological sorting, and reverse connections.

# GreyAlien V15.15

- Completed Timeline Wave 1 for Christopher Mellon, George Knapp, and Jeremy Corbell.
- Reused the existing December 2017 New York Times publication, 2018 Bob Lazar documentary, and WEAPONIZED Episode #115 as authoritative dated timeline records.
- Added shared timeline events for the October 2017 To The Stars Academy launch period, January 2023 WEAPONIZED launch, and January 2024 Jellyfish UAP reporting.
- Added a June 25, 2021 congressional-oversight milestone reflecting Mellon’s documented advocacy for the preliminary UAP assessment.
- Preserved the existing timeline renderer, date filtering, deduplication, and chronological navigation model.

# GreyAlien V15.14

- Added Related Timeline navigation for David Fravor and Ryan Graves.
- Reused the existing July 26, 2023 House UAP hearing as one authoritative shared entity.
- Reused the existing 2004 Nimitz Encounter and Lex Fridman interview entities for David Fravor.
- Added authoritative dated records for the December 2017 New York Times disclosure, the 2014–2015 East Coast Navy encounters, the May 2019 New York Times disclosure, and the June 1, 2023 launch of Americans for Safe Aerospace.
- Added the Americans for Safe Aerospace organization entity to resolve existing graph references.
- No timelines were added for Christopher Mellon, George Knapp, or Jeremy Corbell in this phase.

# GreyAlien V15.13.1

- Refined Related Timeline so only dated entities can appear as timeline cards.
- Excluded Person, Organization, Topic, and Claim entities from Related Timeline.
- Removed the “Date not specified” fallback; undated records remain available in their correct related-entity sections.
- Preserved all existing Timeline entities, relationships, and chronological ordering.

# GreyAlien V15.13

- Added the David Grusch Timeline pilot using a hybrid chronological view.
- Created three new Timeline Event records covering his 2019–2022 UAP assignments, July 2021 protected disclosure, and May 25, 2022 PPD-19 complaint.
- Reused the existing NewsNation interview, WEAPONIZED Episode #21, and July 26, 2023 House UAP Hearing as authoritative dated milestones.
- Updated the entity renderer so Related Timeline can mix Timeline Events with existing dated entity types without duplicating the underlying event.
- Added reverse connections, event dates, event categories, and direct hearing navigation.

# GreyAlien V15.12.1

- Refined Related Timeline cards to display each event date prominently at the top.
- Added the Timeline Event category beneath the date.
- Moved relationship roles into supporting context within each card.
- Added a subtle visual treatment that distinguishes Timeline cards from other entity cards.
- Preserved all Timeline entities, relationships, counts, and chronological ordering.

# GreyAlien V15.12

- Activated the Timeline Event pilot using Bob Lazar as the first person-level chronology.
- Added seven dated timeline events spanning 1982 through April 2026.
- Added role-specific timeline connections and reverse navigation to materially related people, media, organizations, locations, topics, and claims.
- Added foundational entities for KLAS-TV, the Los Alamos Monitor, and two Bob Lazar documentaries.
- Added chronological sorting and Timeline Event details to the generic entity renderer.
- Updated the homepage Latest Additions panel to Version 15.12.

# GreyAlien V15.11.1

* Removed redundant direct Matthew Brown media relationships that duplicated reverse episode-to-guest connections.
* Added entity-page connection deduplication by connected entity ID.
* When duplicate paths exist, the renderer keeps the relationship with the strongest role/context metadata.
* Matthew Brown now displays each WEAPONIZED Part 1–3 episode once under Related Media.
* No homepage, episode-content, or navigation changes.

# GreyAlien V15.11

* Added WEAPONIZED Episode #76 — Matthew Brown Part 3: Immaculate Constellation.
* Connected Jeremy Corbell and George Knapp as hosts and Matthew Brown as guest.
* Added four attributed principal claims focused on alleged visual evidence, perception management, excessive secrecy, and Brown’s call for additional insiders to come forward.
* Updated Matthew Brown's entity record with the official Part 3 source.
* Updated the homepage Latest Additions panel to Version 15.11 and six researched WEAPONIZED episodes.
* Completed the three-part Matthew Brown Immaculate Constellation interview sequence.
* No changes outside the Podcast Knowledge Base and directly connected entity records.

# GreyAlien V15.10

* Added WEAPONIZED Episode #75 — Matthew Brown Part 2: Immaculate Constellation.
* Connected Jeremy Corbell and George Knapp as hosts and Matthew Brown as guest.
* Added three attributed principal claims focused on documents, compartmentalization, and blocked reporting channels.
* Updated Matthew Brown's entity record with the official Part 2 source.
* Updated the homepage Latest Additions panel to Version 15.10 and five researched WEAPONIZED episodes.
* No changes outside the Podcast Knowledge Base and directly connected entity records.

# GreyAlien V15.9

* Added WEAPONIZED — Matthew Brown Part 1: Immaculate Constellation.
* Connected Jeremy Corbell and George Knapp as hosts, Matthew Brown as guest, and Immaculate Constellation as the primary topic.
* Added three focused attributed principal claims using existing claim entities.
* Added a foundational Immaculate Constellation topic entity.
* Updated Matthew Brown's entity record with the official Part 1 interview source.
* Updated the homepage Latest Additions panel to Version 15.9 and four researched WEAPONIZED episodes.
* No changes outside the Podcast Knowledge Base and directly connected entity records.

# GreyAlien V15.8

* Reordered podcast-series entity pages so Related Media appears before Related People.
* Adopted a 3–7 Principal Claims standard for researched podcast episodes.
* Expanded WEAPONIZED Episodes #21, #28, and #115 with attributed, high-value principal claims.
* Rephrased existing relevant claim titles as neutral attributed propositions.
* Added five focused claim entities required to describe the three researched episodes accurately.
* Updated the homepage Latest Additions panel for Version 15.8.
* No changes to the Movies \& Documentaries section or unrelated site areas.

# GreyAlien V15.7

* Added WEAPONIZED Episode #28 as the third researched podcast-episode entity.
* Connected Jeremy Corbell and George Knapp as hosts.
* Connected Ross Coulthart and Bryce Zabel as roundtable guests.
* Connected David Grusch, Ryan Graves, and David Fravor as primary subjects of the post-hearing discussion.
* Connected the episode directly to the July 26, 2023 House UAP hearing and existing congressional-oversight and government-transparency topics.
* Added a foundational Bryce Zabel person entity linked to Need to Know.
* Updated the homepage Latest Additions panel for Version 15.7.
* Added reusable podcast-episode tooling and graph validation to streamline future multi-episode releases.
* No visual redesign or unrelated content additions.

# GreyAlien V15.6

* Added WEAPONIZED Episode #21 as the second researched podcast-episode entity.
* Connected David Grusch to Episode #21 using the `primary\_subject` relationship role.
* Connected Jeremy Corbell and George Knapp as hosts.
* Added focused links to the existing whistleblower-retaliation claim, whistleblower-protection topic, and government-transparency topic.
* Replaced manually stored podcast-card connection totals with counts calculated directly from the knowledge graph.
* Updated the congressional-hearing directory to display witness totals calculated from each structured witness list and warn in the browser console if a stored count disagrees.
* Updated the homepage Latest Additions panel for Version 15.6.
* No visual redesign or unrelated content additions.

# GreyAlien Changelog

## Version 15.5.1

* Corrected the V15.5 homepage Latest Additions panel.
* Added a direct Bob Lazar relationship to WEAPONIZED Episode #115 using the `primary\_subject` role.
* Confirmed Episode #115 remains connected to the WEAPONIZED series and is reachable through the entity graph.

## Version 15.5

* Added contextual relationship roles to the knowledge graph schema.
* Added WEAPONIZED Episode #115 as the first podcast-episode relationship test.
* Added Jeremy Corbell and Luigi Venditelli entity records required by the episode.
* Applied Host, Guest, and Primary Subject roles to Episode #115.
* Renamed the person-page interview connection group to Related Media while leaving Movies \& Documentaries unchanged.

## Version 15.4

* Corrected homepage Knowledge Base Growth totals.
* Added Coming Soon status for every primary section not yet developed.
* Removed remaining numbered version wording from the witness database data title.
* 


## V17.3 — Phase 4 Automation
- Added `tools/automate_site.py` as the authoritative one-command build pipeline.
- Added automated Referenced In and related-podcast-episode generation.
- Added automated homepage Latest Additions updates from structured release data.
- Added machine-readable and Markdown deployment reports.
- Updated transactional imports to use the same build sequence.
- Added progressive entity-page rendering for Related Episodes and Referenced In sections.


## V18.2 — Production Batch #2 + Universal Source System
- Ingested WEAPONIZED Episodes #48–#52.
- Preserved Episode #51 as an unreleased catalog placeholder without invented content.
- Added Ernest Cline and Colm Kelleher entity records.
- Added universal rendering for structured `sources[]`.
- Added official website buttons and additional source panels.
- Added source architecture validation to the one-command automation pipeline.

## V18.2.2 — WEAPONIZED Responsive Banner Refinement
- Replaced WEAPONIZED banner artwork with responsive desert-night identity design.
- Suppressed duplicate text overlays when banner artwork already contains title and host text.
- Updated Latest Additions and retained visual identity validation.

## V18.3 — WEAPONIZED Production Batch #3
- Added Episodes #53–#57 and supporting graph entities.
- Updated homepage Latest Additions and regenerated all automated assets.

## V18.3.1 — Official Links and Reference Sources
- Separated entity-owned links from GreyAlien research provenance.
- Migrated legacy source fields to `officialLinks[]` and `referenceSources[]`.
- Added renderer and validator support for both sections.

## V19.3 — WEAPONIZED Episodes #93–#102
- Added ten content-only production episode records, claims, relationships, timeline events, and official sources.
- Rebuilt generated graph, podcast, related-content, entity-page, homepage, and sitemap outputs.
- No architecture, rendering, template, schema, navigation, UI, styling, or routing changes.

## V19.5
- Added WEAPONIZED Episodes #1–#10 as a content-only production ingestion.
## V20.1 — Related Podcast Series Optimization
- Suppressed a podcast episode’s own parent series from Related Podcast Series.
- Other podcast series remain eligible only through direct cross-series relationships.
- The section is omitted when no qualifying series remains.
- The rule is generic for all current and future podcast series.


## V20.2 — Duplicate Entity Rendering Suppression
- Added canonical-aware duplicate suppression before relationship-card grouping.
- Applied one-card-per-real-world-entity behavior across all relationship sections and Continue Research.
- Added stable podcast episode identity using parent series and episode number.
- Preserved all entity records and knowledge-graph relationships unchanged.

## V20.4 — Knowledge Graph Enrichment, Batch A
- Enriched Bob Lazar with two central documentary and two canonical claim relationships.
- Enriched David Grusch with a direct Episode #116 guest link and two canonical claim relationships.
- Repaired the canonical secret-UAP-program claim attribution and evidence chain to David Grusch and the July 2023 hearing record.
- Enriched Jacques Vallée with three authorship relationships, Episode #102 guest status, and NIDS scientific-advisor affiliation.
- Rebuilt reciprocal discovery and unique graph counts without creating entities or changing presentation architecture.
## V20.5 — Knowledge Graph Enrichment, Batch B
- Added Ryan Graves’s direct claimant relationship to the canonical aviation-safety claim.
- Removed inaccurate Christopher Mellon and Karl Nell claimant edges to David Grusch-specific canonical claims.
- Added Karl Nell’s direct Sol Foundation, UAP Task Force support, SALT presentation, and inaugural Sol symposium relationships.
- Rebuilt reciprocal discovery and unique graph counts without creating entities or changing presentation architecture.


# V21.2 — Need to Know Podcast Integration (Batch 3)

- Added Need to Know Episodes #7–16 as ten content-only production records.
- Added forty source-grounded principal claims and ten podcast-publication timeline events.
- Added direct official YouTube episode links for every new episode while retaining the official collection as the secondary source.
- Reused canonical graph entities and added only five genuinely missing historical or biographical records.
- Preserved all architecture, rendering, schema, template, navigation, routing, UI, styling, and knowledge-graph engine behavior.

## V21.4 — Need to Know Official Media Validation
- Audited all 21 currently ingested Need to Know media records.
- Verified matching primary media and official reference-source URLs for every record.
- Retained the official Need to Know collection as the secondary resource on every episode.
- Corrected the Episode #13 media labeling to identify the linked Bryce Zabel rant as an official unnumbered special.
- Documented the publisher-side conflict in which the May 17, 2022 Elizondo video is titled NTK/13 on YouTube but listed as Episode #14 in the official Need to Know archive.
- Confirmed no duplicate direct-video IDs and no generic archive-page primary links.
- Made no schema, rendering, UI, routing, navigation, architecture, or knowledge-graph changes.

## V21.5 — Need to Know Episodes 22–75

- Added 54 numbered Need to Know episodes, 162 principal claims, and 54 publication timeline events.
- Added direct official YouTube episode links and retained the official collection as the secondary source.
- Reused canonical entities and preserved the content-only production boundary.
- Restored the official NTK/36 David Grusch release, preventing an off-by-one media shift through Episode #74; excluded the unnumbered Spielberg special from the numbered sequence.
- Validated 75 sequential Need to Know records with 75 unique direct official video IDs.

## V22.0 — MERGED Podcast Integration Pilot
- Added MERGED Episode #1 featuring Dr. Garry Nolan and hosted by Ryan Graves.
- Added four source-grounded claims and one historically meaningful launch timeline event.
- Reused existing canonical people, series, organizations, and topics without creating duplicates.
- Added direct official episode-page and YouTube links; cross-series discovery is generated from shared canonical people and topics without forced series edges.
- Preserved the content-only production boundary with no platform changes.

## V23.0 — Podcast Classification Engine

- Added an internal podcast-release classification engine integrated with the Research Accelerator.
- Added Content Class, Episode Type, primary/secondary topic, research-depth, and entity-extraction decisions to reviewable drafts.
- Added explicit human approval before classified podcast records may enter the import pipeline.
- Added classification configuration, JSON schema, command-line classifier, approval tool, and validator.
- Updated podcast ingestion and transactional import validation to require approved V23 classification metadata for new episodes.
- Preserved all existing public rendering, navigation, styles, routes, and entity records.

## V23.4 — Somewhere in the Skies Official Media Link Restoration
- Removed all 40 retired Acast URLs from the 2017 archive.
- Added verified exact episode links where independently matched and explicit Apple Podcasts archive fallbacks elsewhere.
- Regenerated podcast and entity pages and added live-capable media validation.

## V23.5A — Universal Podcast Official Media Architecture
- Added opt-in official-media schema, compatibility adapter, resolver, renderer, validators, live-check mode, approval gates, and fixtures.
- Preserved all existing podcast media records and public legacy behavior.

## V23.5C.1 — Universal Podcast Media Audit Engine and Validation Job Preparation

- Added the permanent offline-first podcast media-audit engine.
- Inventoried 1,449 migrated and legacy media occurrences across 261 podcast entities.
- Generated 491 deterministic platform-aware validation jobs and consolidated 958 duplicate occurrences.
- Added URL normalization, identity expectations, off-by-one preparation, external-result import, repair proposals, rollback manifests, fixtures, and reconciliation reports.
- Explicitly records that production network validation was not run and does not alter live verification states or public preferred destinations.


## V23.5C.2A — Enhanced Live Podcast Audit Runner and Repair Pipeline

- Added production live-audit workflow and bounded platform concurrency.
- Added HTTP 404 failure classification and transport-only `network_unavailable`.
- Added YouTube 429 retry/backoff/jitter and `temporarily_unverifiable`.
- Added dedicated retired `link.chtbl.com` wrapper handling.
- Added metadata, platform, destination-type, RSS, soft-404, and episode identity validation.
- Added repair proposals, automatic and human-review queues, transactional previews, rollback snapshots, and series/cross-series reports.
- Preserved all public podcast media data pending explicit approval.

## V23.5C.2B — GitHub Actions Live Podcast Media Validation Runner

- Added a dedicated manually triggered production workflow for all 491 prepared live-validation jobs.
- Added optional bounded test execution through the `job_limit` workflow input.
- Added live evidence, repair queues, proposal reports, transaction preview, rollback snapshot, revision recording, and operator summary artifacts.
- Preserved the approval boundary: the workflow does not import unreviewed repairs or change knowledge-graph data.
- Added production run documentation and artifact retrieval instructions.

## V23.5C.2B.1 — Apple Podcasts Identity & Repair Proposal Deduplication

- Added dedicated Apple Podcasts metadata extraction with provenance and confidence.
- Preserved Apple episode identifiers through redirects and canonical normalization.
- Distinguished direct Apple episode URLs from show pages.
- Added deterministic episode identity scoring and conflict safeguards.
- Consolidated redundant repair findings into unique proposals with nested candidates.
- Added Apple diagnostics and regression tests.
- Preserved approval-gated transactions and made no production media or graph changes.

## V23.5C.2B.3 — Apple Metadata Source Prioritization and Episode Title Extraction

- Rejects `@ApplePodcasts` and normalized Apple platform-branding variants from podcast and episode identity fields.
- Rejects exact generic Apple playback/interface labels such as `Play`, `Listen Now`, and `Preview` as episode titles.
- Preserves legitimate podcast and episode titles containing words such as Apple, Play, or Preview.
- Selects the highest-priority valid Apple metadata candidate using deterministic confidence and source precedence.
- Adds accepted/rejected diagnostics, insufficient-metadata reporting, nine regression fixtures, and focused parser tests.
- Preserves workflows, schemas, proposal deduplication, approval gating, transactions, production media data, rendering, and knowledge-graph files.
